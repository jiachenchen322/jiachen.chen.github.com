We provide versions under UNIX and Windows.

Files for Windows:
swdpwr_macro_win.sas 
swdnew.exe

Files for UNIX:
swdpwr_macro_unix.sas 
swdnew

The proper directory to swdnew should be modified in the *.sas file in line "%let mydir=...".

