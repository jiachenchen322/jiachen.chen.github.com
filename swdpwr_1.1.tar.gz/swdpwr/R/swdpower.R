#' A wrap of power calculation for Stepped Wedge Design Studies.
#' @description This function performs power calculations for stepped wedge cluster randomized trials under different scenarios.
#' @param I number of clusters
#' @param J number of time periods
#' @param K number of participants at each time step from every cluster
#' @param dataset data set that describes the study design (control 0, intervention 1)
#' @param response choose continuous outcome(response=1) or binary outcome(response=2), with default value of 2
#' @param model choose conditional model (model=1) or marginal model(model=2), with default value of 2
#' @param link choose link function (identity 1, log 2, logit 3), with default value of 1
#' @param mu baseline effect in control groups
#' @param beta treatment effect (the parameter we would like to test)
#' @param gammaJ time effect at time period J, with default value of 0
#' @param sigma2 marginal variance of the outcome (only needed for continuous outcomes)
#' @param alpha two-sided type I error, with default value of 0.05
#' @param ICC0 within-period correlation
#' @param ICC1 inter-period correlation
#' @param ICC2 within-individual correlation
#' @return The object returned is a list, which includes the design matrix and a summary table of this design (including the power).
#' @examples
#' library(swdpwr)
#' #designs for binary outcomes: parameter sigma2 is not required.
#' dataset = matrix(c(rep(c(0,1,1),6),rep(c(0,0,1),6)),12,3,byrow=TRUE)
#' swdpower(I = 12, J = 3, K = 50, dataset, response = 2, model = 2, link = 3,
#' mu = -0.9, beta= 0.5, gammaJ= 0.2, alpha = 0.05, ICC0 = 0.01, ICC1 = 0.01, ICC2 = 0.01)
#' #designs for continuous outcomes: parameter sigma2 is required.
#' dataset = matrix(c(rep(c(0,1,1),4),rep(c(0,0,1),4)),8,3, byrow=TRUE)
#' swdpower(I = 8, J = 3, K = 24, dataset, response = 1, model = 2, link = 1,
#' mu = 0.1, beta = 0.2, gammaJ = 0.1, sigma2 = 0.095, alpha = 0.05, ICC0 = 0.03,
#' ICC1 = 0.015, ICC2 = 0.2)
#' @export

swdpower<-function(I,J,K,dataset,response=2,model=2,link=1,mu,beta,gammaJ=0,sigma2=0,alpha=0.05,ICC0=0.1,ICC1=ICC0/2,ICC2)
{
  II=I
  JJ=J
  KK=K
  X_in=dataset
  res=response
  opt=model
  mu=mu
  beta=beta
  p0totalchange=gammaJ
  sigma2=sigma2
  rho0=ICC1
  typeone=alpha
  link=link-1


  TOLERANCE = 1e-5
  convergence = 0
  p0 = rep(0,JJ)
  gamma = rep(0,JJ)
  mincomp = rep(0,JJ+2)
  maxcomp = rep(0,JJ+2)
  #initialization
  tau2=1
  power=0



  temp1=c(ICC0,ICC1,ICC2)
  if(max(temp1)>1) stop('Violate range of ICC: max(ICC0,ICC1,ICC2)>1.Please correct the values of correlation parameters (between 0 and 1).')

  temp1=c(ICC0,ICC1,ICC2)
  if(min(temp1)<0) stop('Violate range of ICC: min(ICC0,ICC1,ICC2)<0.Please correct the values of correlation parameters (between 0 and 1).')

  if(typeone>1) stop("Type I error is larger than 1, it should be between 0 and 1.")
  if(typeone<0) stop("Type I error is less than 0, it should be between 0 and 1.")

  if(res>1.5){

      if(opt<1.5)
  {
    if (p0totalchange > TOLERANCE | p0totalchange < -TOLERANCE)
      {
       if(link<1)
       {
         GQ=100
         GQX = rep(0,GQ)
         GQW = rep(0,GQ)
         p01=mu
         p11=mu+beta
         p0[1] = p01
         p11 = p11
         p0stepchange = p0totalchange/(JJ-1)
         for(j in 2:JJ)
         {
           p0[j]= p0[j-1] + p0stepchange
         }
         #  call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
         #dyn.load("computeparameter.so")
         mu=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
         beta=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
         gamma=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
         tau2=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$tau2

         temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
         if(min(temp1)<0) stop("Violate theory of possibility under indentity link: min(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)<0. Please check whether any of these four values are out of range.")

         temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
         if(max(temp1)>1) stop('Violate theory of possibility under indentity link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>1. Please check whether any of these four values are out of range.')

         a = 100
         b = -100
         for(j in 1:JJ)
         {
           temp = mu+gamma[j]
           if (temp < a){
             a = temp
             mincomp=rep(0,JJ+2)
             mincomp[JJ+1] = 1
             mincomp[j] = 1
           }

           if (temp > b){
             b = temp
             maxcomp=rep(0,JJ+2)
             maxcomp[JJ+1] = 1
             maxcomp[j] = 1
           }
           temp = mu+beta+gamma[j]
           if (temp < a){
             a = temp
             mincomp= rep(0,JJ+2)
             mincomp[JJ+1] = 1
             mincomp[JJ+2] = 1
             mincomp[j] = 1
           }

           if (temp > b){
             b = temp
             maxcomp= rep(0,JJ+2)
             maxcomp[JJ+1] = 1
             maxcomp[JJ+2] = 1
             maxcomp[j] = 1
           }
         }
         a = -a
         b = 1-b
         #call legendre_handle (GQ, a, b, GQX, GQW)
         ##dyn.load("legendre_rule.so")
         GQX=.Fortran("legendre_handle",GQ=as.integer(GQ), a=as.numeric(a), b=as.numeric(b), GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQX
         GQW=.Fortran("legendre_handle",GQ=as.integer(GQ), a=as.numeric(a), b=as.numeric(b), GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQW
         #Gaussian Legendre will not take two limits, a and b
         #power = LinearPower_time(mu, beta, gamma, tau2, II, JJ, KK, a, b, mincomp, maxcomp, GQ, GQX, GQW, X_in)
         #dyn.load("power_cal_wrapper.so")
         power=.Fortran("LinearPower_time_wrapper",mu=mu, beta, gamma=gamma, tau2=tau2, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), a=as.numeric(a), b=as.numeric(b), mincomp=as.integer(mincomp), maxcomp=as.integer(maxcomp), GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), X_in=as.integer(X_in),typeone=as.numeric(typeone),power=power,package="swdpwr")$power

       }
      else if(link<2 & link>0)
      {
        GQ=500
        GQX = rep(0,GQ)
        GQW = rep(0,GQ)
        gamma = rep(0,JJ)
        p01= exp(mu)
        p0[1] = p01
        p11 = exp(mu+beta)
        p11 = p11
        p0stepchange = p0totalchange/(JJ-1)
        for(j in 2:JJ)
        {
          gamma[j]= gamma[j-1] + p0stepchange
        }
        for(j in 2:JJ)
        {
          p0[j]= exp(gamma[j]+mu)
        }
        #  call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
        #dyn.load("computeparameterlog.so")
        mu=.Fortran("computeparameterlog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
        beta=.Fortran("computeparameterlog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
        gamma=.Fortran("computeparameterlog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
        tau2=.Fortran("computeparameterlog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$tau2

        temp1=c(mu+p0totalchange,mu+beta+p0totalchange,mu,mu+beta)
        if(max(temp1)>0) stop('Violate theory of possibility under log link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>0.Please check whether any of these four values are out of range.')




        a = 100
        b = -100
        for(j in 1:JJ)
        {
          temp = mu+gamma[j]
          if (temp < a){
            a = temp
            mincomp= rep(0,JJ+2)
            mincomp[JJ+1] = 1
            mincomp[j] = 1
          }

          if (temp > b){
            b = temp
            maxcomp= rep(0,JJ+2)
            maxcomp[JJ+1] = 1
            maxcomp[j] = 1
          }
          temp = mu+beta+gamma[j]
          if (temp < a){
            a = temp
            mincomp= rep(0,JJ+2)
            mincomp[JJ+1] = 1
            mincomp[JJ+2] = 1
            mincomp[j] = 1
          }

          if (temp > b){
            b = temp
            maxcomp= rep(0,JJ+2)
            maxcomp[JJ+1] = 1
            maxcomp[JJ+2] = 1
            maxcomp[j] = 1
          }
        }
        if (beta>0)
        {
          a= 5000
        }else
        { a= 5000 }

        b = b
        #call legendre_handle (GQ, b, a, GQX, GQW)
        #!call legendre_handle2 (GQ, b, a, GQX, GQW)
        #dyn.load("legendre_rule.so")
        GQX=.Fortran("legendre_handle",GQ=as.integer(GQ), a=b, b=a, GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQX
        GQW=.Fortran("legendre_handle",GQ=as.integer(GQ), a=b, b=a, GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQW

        #Gaussian Legendre will not take two limits, a and b
        #power = LogPower_time(mu, beta, gamma, tau2, II, JJ, KK, b, a, mincomp, maxcomp, GQ, GQX, GQW, X_in)
        #dyn.load("power_cal_wrapper.so")
        power=.Fortran("LogPower_time_wrapper",mu=mu, beta=beta, gamma=gamma, tau2=tau2, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), a=b, b=a, mincomp=as.integer(mincomp), maxcomp= as.integer(maxcomp), GQ=as.integer(GQ),GQX=as.numeric(GQX), GQW=as.numeric(GQW), X_in=as.integer(X_in),typeone=as.numeric(typeone),power=power,package="swdpwr")$power

      }else
       {
         GQ = 40
         GQX = rep(0,GQ)
         GQW = rep(0,GQ)
         #call HERZO(GQ,GQX,GQW)
         #dyn.load("herzo.so")
         GQW=.Fortran("HERZO",GQ=as.integer(GQ),GQX=as.numeric(GQX),GQW=as.numeric(GQX),package="swdpwr")$GQW
         GQX=.Fortran("HERZO",GQ=as.integer(GQ),GQX=as.numeric(GQX),GQW=as.numeric(GQX),package="swdpwr")$GQX
         p01=exp(mu)/(1+exp(mu))
         p11=exp(mu+beta)/(1+exp(mu+beta))
         p0[1] = p01
         p11 = p11
         p0stepchange = p0totalchange/(JJ-1)
         for(j in 2:JJ)
         {
           gamma[j]= gamma[j-1] + p0stepchange
         }
         for(j in 2:JJ)
         {
           p0[j]= exp(gamma[j]+mu)/(1+exp(mu+gamma[j]))
         }
         #initial values
         mual=mu
         betaal=beta
         gammaal=gamma
         tau2 = 1.0
         #gamma = 0.0
         #call computeparameterlogit(JJ, mu, beta, gamma, tau2, p0, p11, rho0, GQ, GQX, GQW, convergence)
         #dyn.load("computeparameterlogit.so")
         mu=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0, GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$mu
         beta=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0, GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$beta
         gamma=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0, GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$gamma
         tau2=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0, GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$tau2
         mu=mual
         beta=betaal
         gamma=gammaal
         #power = LogitPower_time(mu, beta, gamma, tau2, II, JJ, KK, GQ, GQX, GQW,X_in)
         #dyn.load("power_cal_wrapper.so")
         power=.Fortran("LogitPower_time_wrapper",mu=mu, beta=beta, gamma=gamma, tau2=tau2, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), X_in=as.integer(X_in),typeone=as.numeric(typeone), power=power,package="swdpwr")$power

      }
      }
    else
     {
       if(link<1)
       {

         GQ=100
         GQX = rep(0,GQ)
         GQW = rep(0,GQ)
         p01=mu
         p11=beta+mu
         p0[1] = p01
         p11 = p11
         p0stepchange = p0totalchange/(JJ-1)
         for(j in 2:JJ)
         {
           p0[j]= p0[j-1] + p0stepchange
         }
         #call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
         #dyn.load("computeparameter.so")
         mu=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
         beta=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
         tau2=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$tau2

         temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
         if(min(temp1)<0) stop("Violate theory of possibility under indentity link: min(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)<0.Please check whether any of these four values are out of range.")

         temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
         if(max(temp1)>1) stop('Violate theory of possibility under indentity link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>1.Please check whether any of these four values are out of range.')

          if (beta>0){
           a = - mu
           b = 1 - mu - beta
         }else
         {
           a = - mu - beta
           b = 1 - mu
         }
         #! a = a / dsqrt(2.0d0*tau2)
         #! b = b / dsqrt(2.0d0*tau2)
         #call legendre_handle (GQ, a, b, GQX, GQW)
         #! Gaussian Legendre will not take two limits, a and b
         #power = LinearPower_notime(mu, beta, tau2, II, JJ, KK, a, b, GQ, GQX, GQW, X_in)
         #dyn.load("legendre_rule.so")
         GQX=.Fortran("legendre_handle",GQ=as.integer(GQ), a=a, b=b, GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQX
         GQW=.Fortran("legendre_handle",GQ=as.integer(GQ), a=a, b=b, GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQW
         #dyn.load("power_cal_wrapper.so")
         power=.Fortran("LinearPower_notime_wrapper",mu=mu, beta=beta,  tau2=tau2, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), a=a, b=b, GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), X_in=as.integer(X_in) ,typeone=as.numeric(typeone), power=power,package="swdpwr")$power
       }
       else if(link<2 & link>0)
       {

         GQ=500
         GQX = rep(0,GQ)
         GQW = rep(0,GQ)
         p01= exp(mu)
         p0[1] = p01
         p11 = exp(mu+beta)
         p11 = p11
         p0stepchange = p0totalchange/(JJ-1)
         for(j in 2:JJ)
         {
           gamma[j]= gamma[j-1] + p0stepchange
         }
         for(j in 2:JJ)
         {
           p0[j] = exp(gamma[j]+mu)
         }

         temp1=c(mu+p0totalchange,mu+beta+p0totalchange,mu,mu+beta)
         if(max(temp1)>0) stop('Violate theory of possibility under log link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>0.Please check whether any of these four values are out of range.')

         #call computeparameterlog(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
         #dyn.load("computeparameterlog.so")
         mu=.Fortran("computeparameterlog",JJ=as.integer(JJ),mu=mu,beta=beta,gamma=gamma,tau2=tau2,p0=p0,p11=p11, rho0=rho0,package="swdpwr")$mu
         beta=.Fortran("computeparameterlog",JJ=as.integer(JJ), mu=mu, beta=beta,gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
         tau2=.Fortran("computeparameterlog",JJ=as.integer(JJ), mu=mu, beta=beta,gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$tau2

         if (beta>0) {
           #!inf= 0
           #!a = 0.5d0/tau2
           a= 5000.0
           #!a=0.05
           b = - mu - beta

         }else{
           # !inf= 0
           #!a =0.5d0/tau2
           a= 5000.0
           #!a=0.05
           b =  - mu
         }
         #! a = a / dsqrt(2.0d0*tau2)
         #! b = b / dsqrt(2.0d0*tau2)
         b=-b
         # !b=0
         # call legendre_handle (GQ, b, a, GQX, GQW)
         # !  call legendre_handle2 (GQ, b, a, GQX, GQW)
         # ! Gaussian Legendre will not take two limits, a and b
         # power = LogPower_notime(mu, beta, tau2, II, JJ, KK, b, a, GQ, GQX, GQW, X_in)
         #dyn.load("legendre_rule.so")
         GQX=.Fortran("legendre_handle",GQ=as.integer(GQ), a=b, b=a, GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQX
         GQW=.Fortran("legendre_handle",GQ=as.integer(GQ), a=b, b=a, GQX=as.numeric(GQX), GQW=as.numeric(GQW),package="swdpwr")$GQW
         #Gaussian Legendre will not take two limits, a and b
         #dyn.load("power_cal_wrapper.so")
         power=.Fortran("LogPower_notime_wrapper",mu=mu, beta=beta, tau2=tau2, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), a=b,b=a,GQ=as.integer(GQ),GQX=as.numeric(GQX), GQW=as.numeric(GQW), X_in=as.integer(X_in) ,typeone=as.numeric(typeone), power=power,package="swdpwr")$power

         }
       else
       {
         GQ = 40
         GQX = rep(0,GQ)
         GQW = rep(0,GQ)
         #call HERZO(GQ,GQX,GQW)
         #dyn.load("herzo.so")
         GQX=.Fortran("HERZO",GQ=as.integer(GQ),GQX=as.numeric(GQX),GQW=as.numeric(GQW),package="swdpwr")$GQX
         GQW=.Fortran("HERZO",GQ=as.integer(GQ),GQX=as.numeric(GQX),GQW=as.numeric(GQW),package="swdpwr")$GQW
         p0totalchange=0
         p01=exp(mu)/(1+exp(mu))
         p11=exp(mu+beta)/(1+exp(mu+beta))
         p0[1] = p01
         p11 = p11
         p0stepchange = p0totalchange/(JJ-1)
         for(j in 2:JJ)
         {
           gamma[j]= gamma[j-1] + p0stepchange
         }
         for(j in 2:JJ)
         {
           p0[j]= exp(gamma[j]+mu)/(1+exp(mu+gamma[j]))
         }

         mual=mu
         betaal=beta
         gammaal=gamma
         tau2 = 1.0
         #gamma = 0.0
         #call computeparameterlogit(JJ, mu, beta, gamma, tau2, p0, p11, rho0, GQ, GQX, GQW, convergence)
         #power = LogitPower_notime(mu, beta, tau2, II, JJ, KK, GQ, GQX, GQW,X_in)
         #dyn.load("computeparameterlogit.so")
         mu=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$mu
         beta=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$beta
         tau2=.Fortran("computeparameterlogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), convergence=convergence,package="swdpwr")$tau2
         #dyn.load("power_cal_wrapper.so")
         mu=mual
         beta=betaal
         gamma=gammaal
         power=.Fortran("LogitPower_notime_wrapper",mu=mu, beta=beta, tau2=tau2, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), GQ=as.integer(GQ), GQX=as.numeric(GQX), GQW=as.numeric(GQW), X_in=as.integer(X_in), typeone=as.numeric(typeone),power=power,package="swdpwr")$power

       }
      }
  }
 else
 {
   alpha0= ICC0
   alpha1= rho0
   alpha2= ICC2
   lambda1 = 1- alpha0 + alpha1 - alpha2
   lambda2 = 1- alpha0 - (JJ-1)*(alpha1 - alpha2)
   lambda3 = 1 + (KK-1)*(alpha0 - alpha1) - alpha2
   lambda4 = 1 + (KK-1)*alpha0 + (JJ-1)*(KK-1)*alpha1 + (JJ-1)*alpha2
   temp2=c(lambda1,lambda2,lambda3,lambda4)
   if(min(temp2)<0) stop('Correlation matrix R is no longer positive definite. Please check whether the inter-period correlation is unrealistically larger than the within-period correlation or the within-individual correlation.')

   #if(ICC1>ICC0)  stop('ICC1>ICC0')


   #if(ICC1>ICC2)  stop('ICC1>ICC2')

   if (p0totalchange > TOLERANCE | p0totalchange < -TOLERANCE)
   {
     if(link<1)
     {
       p01=mu
       p11=mu+beta
       p0[1] = p01
       p11 = p11
       p0stepchange = p0totalchange/(JJ-1)
       for(j in 2:JJ)
       {
         p0[j]= p0[j-1] + p0stepchange
       }

       temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
       if(min(temp1)<0) stop("Violate theory of possibility under indentity link: min(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)<0.Please check whether any of these four values are out of range.")

       temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
       if(max(temp1)>1) stop('Violate theory of possibility under indentity link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>1.Please check whether any of these four values are out of range.')

       #call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
       #dyn.load("computeparameter.so")
       mu=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
       beta=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
       gamma=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
       rho0=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$rho0
       #power=LinearPower_GEE(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("power_cal_wrapper.so")
       period=NULL
       period=gamma+mu
       period[JJ+1]=beta
       X=matrix(0,JJ,JJ+1)
       X[,1:JJ]=diag(JJ)
       for(i in 1:II)
       {
         X[,JJ+1]=X_in[i,]
         gmu=X%*%as.matrix(period)
         mmu=(gmu*(1-gmu))^0.5
         for(m in 1:JJ)
         {
          if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))>gmu[m]) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))>gmu(m)')
          if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))<max(2*gmu[m]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))<max(0,2*gmu(m)-1)')
         }
         for(m in 1:(JJ-1))
           for(k in (m+1):JJ)
           {
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('((gmu(m)*gmu(k)+alpha1*(1/mmu(m,m))*(1/mmu(k,k))))>min(gmu(m),gmu(k))')
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha1*(1/mmu(m,m))*(1/mmu(k,k))))<max(0,gmu(m)+gmu(k)-1)')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha2*(1/mmu(m,m))*(1/mmu(k,k))))>min(gmu(m),gmu(k))')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha2*(1/mmu(m,m))*(1/mmu(k,k))))<max(0,gmu(m)+gmu(k)-1)')
             }
       }



       power=.Fortran("LinearPower_GEE_wrapper",mu=mu, beta=beta, gamma=gamma, rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power=power,package="swdpwr")$power

     }
     else if(link<2 & link>0)
     {
       p01=exp(mu)
       p11=exp(mu+beta)
       p0[1] = p01
       p11 = p11
       p0stepchange = p0totalchange/(JJ-1)
       for(j in 2:JJ)
       {
         gamma[j]= gamma[j-1] + p0stepchange
       }
       for(j in 2:JJ)
       {
         p0[j] = exp(gamma[j]+mu)
       }
       temp1=c(mu+p0totalchange,mu+beta+p0totalchange,mu,mu+beta)
       if(max(temp1)>0) stop('Violate theory of possibility under log link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>0.Please check whether any of these four values are out of range.')

       #call computeparameterGEElog(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
       #dyn.load("computeparameterGEElog.so")
       mu=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
       beta=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
       gamma=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
       rho0=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$rho0
       #power=LogPower_GEE(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("power_cal_wrapper.so")
       period=NULL
       period=gamma+mu
       period[JJ+1]=beta
       X=matrix(0,JJ,JJ+1)
       X[,1:JJ]=diag(JJ)
       for(i in 1:II)
       {
         X[,JJ+1]=X_in[i,]
         gmu=X%*%as.matrix(period)
         gmu=exp(gmu)
         mmu=(gmu*(1-gmu))^0.5
         for(m in 1:JJ)
         {
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))>gmu[m]) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))>gmu(m)')
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))<max(2*gmu[m]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))<max(0,2*gmu(m)-1)')
         }
         for(m in 1:(JJ-1))
           for(k in (m+1):JJ)
           {
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha1*(1/mmu(m,m))*(1/mmu(k,k))))>min(gmu(m),gmu(k))')
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0))  stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha1*(1/mmu(m,m))*(1/mmu(k,k))))<max(0,gmu(m)+gmu(k)-1)')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha2*(1/mmu(m,m))*(1/mmu(k,k))))>min(gmu(m),gmu(k))')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu(m)*gmu(k)+alpha2*(1/mmu(m,m))*(1/mmu(k,k))))<max(0,gmu(m)+gmu(k)-1)')
           }
       }


       power=.Fortran("LogPower_GEE_wrapper",mu=mu, beta=beta, gamma=gamma, rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power=power,package="swdpwr")$power
     }
     else
     {
       p01=exp(mu)/(1+exp(mu))
       p11=exp(mu+beta)/(1+exp(mu+beta))
       p0[1] = p01
       p11 = p11
       p0stepchange = p0totalchange/(JJ-1)
       for(j in 2:JJ)
       {
         gamma[j]= gamma[j-1] + p0stepchange
       }
       for(j in 2:JJ)
       {
         p0[j]= exp(gamma[j]+mu)/(1+exp(mu+gamma[j]))
       }
       #call computeparameterGEElogit(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
       #power=LogitPower_GEE(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("computeparameterGEElogit.so")
       mu=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
       beta=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
       gamma=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
       rho=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$rho0
       #dyn.load("power_cal_wrapper.so")
       period=NULL
       period=gamma+mu
       period[JJ+1]=beta
       X=matrix(0,JJ,JJ+1)
       X[,1:JJ]=diag(JJ)
       for(i in 1:II)
       {
         X[,JJ+1]=X_in[i,]
         gmu=X%*%as.matrix(period)
         gmu=exp(gmu)/(1+exp(gmu))
         mmu=(gmu*(1-gmu))^0.5
         for(m in 1:JJ)
         {
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))>gmu[m]) stop('Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.')
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))<max(2*gmu[m]-1,0)) stop('Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.')
         }
         for(m in 1:(JJ-1))
           for(k in (m+1):JJ)
           {
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
           }
       }

       power=.Fortran("LogitPower_GEE_wrapper",mu=mu, beta=beta, gamma=gamma, rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power= power,package="swdpwr")$power
       }
   }
   else
   {
     if(link<1)
     {
       p01=mu
       p11=beta+mu
       p0[1] = p01
       p11 = p11
       p0stepchange = p0totalchange/(JJ-1)
       for(j in 2:JJ)
       {
         p0[j]= p0[j-1] + p0stepchange
       }
       temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
       if(min(temp1)<0) stop("Violate theory of possibility under indentity link: min(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)<0.Please check whether any of these four values are out of range.")

       temp1=c(p01+p0totalchange,p11+p0totalchange,p01,p11)
       if(max(temp1)>1) stop('Violate theory of possibility under indentity link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>1.Please check whether any of these four values are out of range.')

       #call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
       #power=LinearPower_GEE_notime(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("computeparameter.so")
       mu=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
       beta=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
       gamma=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
       rho0=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$rho0
       #power=LinearPower_GEE(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("power_cal_wrapper.so")
       period=NULL
       period[1]=mu
       period[2]=beta
       X=matrix(1,JJ,2)

       for(i in 1:II)
       {
         X[,2]=X_in[i,]
         gmu=X%*%as.matrix(period)
         mmu=(gmu*(1-gmu))^0.5
         for(m in 1:JJ)
         {
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))>gmu[m]) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))>gmu(m)')
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))<max(2*gmu[m]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))<max(0,2*gmu(m)-1)')
         }
         for(m in 1:(JJ-1))
           for(k in (m+1):JJ)
           {
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
           }
       }
       power=.Fortran("LinearPower_GEE_notime_wrapper",mu=mu, beta=beta, gamma=gamma, rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone), power=power,package="swdpwr")$power
       }
     else if(link<2 & link>0)
     {
       p01=exp(mu)
       p11=exp(mu+beta)
       p0[1] = p01
       p11 = p11
       p0stepchange = p0totalchange/(JJ-1)
       for(j in 2:JJ)
       {
         gamma[j]= gamma[j-1] + p0stepchange
       }
       for(j in 2:JJ)
       {
         p0[j] = exp(gamma[j]+mu)
       }
       temp1=c(mu+p0totalchange,mu+beta+p0totalchange,mu,mu+beta)
       if(max(temp1)>0) stop('Violate theory of possibility under log link: max(mu+gammaJ,mu+beta+gammaJ,mu,mu+beta)>0.Please check whether any of these four values are out of range.')

       #call computeparameterGEElog(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
       #power=LogPower_GEE_notime(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("computeparameterGEElog.so")
       mu=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
       beta=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
       gamma=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
       rho0=.Fortran("computeparameterGEElog",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$rho0
       #power=LogPower_GEE(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("power_cal_wrapper.so")
       period=NULL
       period[1]=mu
       period[2]=beta
       X=matrix(1,JJ,2)
       for(i in 1:II)
       {
         X[,2]=X_in[i,]
         gmu=X%*%as.matrix(period)
         gmu=exp(gmu)
         mmu=(gmu*(1-gmu))^0.5
         for(m in 1:JJ)
         {
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))>gmu[m]) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")# stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))>gmu(m)')
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))<max(2*gmu[m]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))<max(0,2*gmu(m)-1)')
         }
         for(m in 1:(JJ-1))
           for(k in (m+1):JJ)
           {
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0))  stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
           }
       }

       power=.Fortran("LogPower_GEE_notime_wrapper",mu=mu, beta=beta, gamma=gamma, rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power=power,package="swdpwr")$power
      }
     else
     {
       p01=exp(mu)/(1+exp(mu))
       p11=exp(mu+beta)/(1+exp(mu+beta))
       p0[1] = p01
       p11 = p11
       p0stepchange = p0totalchange/(JJ-1)
       for(j in 2:JJ)
       {
         gamma[j]= gamma[j-1] + p0stepchange
       }
       for(j in 2:JJ)
       {
         p0[j]= exp(gamma[j]+mu)/(1+exp(mu+gamma[j]))
       }
       #call computeparameterGEElogit(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
       #power=LogitPower_GEE_notime(mu, beta, gamma, rho0, II, JJ, KK, X_in)
       #dyn.load("computeparameterGEElogit.so")
       mu=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
       beta=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
       gamma=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
       rho0=.Fortran("computeparameterGEElogit",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$rho0
       #dyn.load("power_cal_wrapper.so")
       period=NULL
       period[1]=mu
       period[2]=beta
       X=matrix(1,JJ,2)
       for(i in 1:II)
       {
         X[,2]=X_in[i,]
         gmu=X%*%as.matrix(period)
         gmu=exp(gmu)/(1+exp(gmu))
         mmu=(gmu*(1-gmu))^0.5
         for(m in 1:JJ)
         {
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))>gmu[m]) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))>gmu(m)')
           if((gmu[m]*gmu[m]+alpha0*gmu[m]*(1-gmu[m]))<max(2*gmu[m]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('(gmu(m)*gmu(m)+alpha0*gmu(m)*(1-gmu(m)))<max(0,2*gmu(m)-1)')
         }
         for(m in 1:(JJ-1))
           for(k in (m+1):JJ)
           {
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0))  stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha1*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))>min(c(gmu[m],gmu[k]))')
             if(((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)) stop("Correlation paramters do not satisfy the restrictions of Qaqish (2003). Please check whether it is possible to reduce the large difference between baseline mean response and mean response at the end of the trial, or make adjustments to the ICCs.")#stop('((gmu[m]*gmu[k]+alpha2*(mmu[m])*(mmu[k])))<max(gmu[m]+gmu[k]-1,0)')
           }
       }
       power=.Fortran("LogitPower_GEE_notime_wrapper",mu=mu, beta=beta, gamma=gamma, rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power=power,package="swdpwr")$power
    }
   }
 }
  }
  else{
    alpha0= ICC0
    alpha1= rho0
    alpha2= ICC2
    lambda1 = 1- alpha0 + alpha1 - alpha2
    lambda2 = 1- alpha0 - (JJ-1)*(alpha1 - alpha2)
    lambda3 = 1 + (KK-1)*(alpha0 - alpha1) - alpha2
    lambda4 = 1 + (KK-1)*alpha0 + (JJ-1)*(KK-1)*alpha1 + (JJ-1)*alpha2
    temp2=c(lambda1,lambda2,lambda3,lambda4)
    if(min(temp2)<0) stop('Correlation matrix R is no longer positive definite. Please check whether the inter-period correlation is unrealistically larger than the within-period correlation or the within-individual correlation.')
   # if(ICC1>ICC0)  stop('ICC1>ICC0')


    #if(ICC1>ICC2)  stop('ICC1>ICC2')
    if (p0totalchange > TOLERANCE | p0totalchange < -TOLERANCE)
    {   p01=mu
        p11=mu+beta
      p0[1] = p01
      p11 = p11
      p0stepchange = p0totalchange/(JJ-1)
      for(j in 2:JJ)
      {
        p0[j]= p0[j-1] + p0stepchange
      }
      #  call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
      #dyn.load("computeparameter.so")
      mu=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
      beta=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
      gamma=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
      tau2=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$tau2
      power=.Fortran("ContinuousPower_GEE_time_wrapper",mu=mu, beta=beta, gamma=gamma,rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),sigma2=sigma2,ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power=power,package="swdpwr")$power
    }
    else
      { p01=mu
        p11=mu+beta
        p0[1] = p01
        p11 = p11
        p0stepchange = p0totalchange/(JJ-1)
        for(j in 2:JJ)
        {
          p0[j]= p0[j-1] + p0stepchange
        }
        #  call computeparameter(JJ, mu, beta, gamma, tau2, p0, p11, rho0)
        #dyn.load("computeparameter.so")
        mu=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$mu
        beta=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$beta
        gamma=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$gamma
        tau2=.Fortran("computeparameter",JJ=as.integer(JJ), mu=mu, beta=beta, gamma=gamma, tau2=tau2, p0=p0, p11=p11, rho0=rho0,package="swdpwr")$tau2
        power=.Fortran("ContinuousPower_GEE_notime_wrapper",mu=mu, beta=beta, gamma=gamma,rho0=rho0, II=as.integer(II), JJ=as.integer(JJ), KK=as.integer(KK), X_in=as.integer(X_in),sigma2=sigma2,ICC0=ICC0,ICC2=ICC2,typeone=as.numeric(typeone),power=power,package="swdpwr")$power
    }
  }
#summary

  if(rho0<ICC2) SS=II*KK
  else SS=II*KK*JJ

if(response<1.5) {
  summary=matrix(data=c(I,J,K,SS,response,model,link+1,mu,beta,gammaJ,sigma2,ICC0,ICC1,ICC2,alpha,power),ncol=1)
  rownames(summary)=c("I","J","K","total sample size","response","model","link","baseline effect mu","treatment effect beta","time effect gamma_j","marginal variance","ICC0","ICC1","ICC2","Type I error","Power")
  design_matrix=dataset
  list_data =list(design_matrix,summary)
  names(list_data)=c("design matrix dataset, row-cluster col-time","Summary")
  return(list_data)
}

  if(response>1.5) {
    summary=matrix(data=c(I,J,K,SS,response,model,link+1,mu,beta,gammaJ,ICC0,ICC1,ICC2,alpha,power),ncol=1)
    rownames(summary)=c("I","J","K","total sample size","response","model","link","baseline effect mu","treatment effect beta","time effect gamma_j","ICC0","ICC1","ICC2","Type I error","Power")
    design_matrix=dataset
    list_data =list(design_matrix,summary)
    names(list_data)=c("design matrix dataset, row-cluster col-time","Summary")
    return(list_data)
}

}


