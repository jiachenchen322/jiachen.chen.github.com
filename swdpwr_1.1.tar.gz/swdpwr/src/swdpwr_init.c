#include <R_ext/RS.h>
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME:
   Check these declarations against the C/Fortran source code.
*/

/* .Fortran calls */
extern void F77_NAME(computeparameter)(void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(computeparametergeelog)(void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(computeparametergeelogit)(void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(computeparameterlog)(void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(computeparameterlogit)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(continuouspower_gee_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(continuouspower_gee_time_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(herzo)(void *, void *, void *, void *);
extern void F77_NAME(legendre_handle)(void *, void *, void *, void *, void *, void *);
extern void F77_NAME(linearpower_gee_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(linearpower_gee_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(linearpower_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(linearpower_time_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logitpower_gee_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logitpower_gee_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logitpower_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logitpower_time_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logpower_gee_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logpower_gee_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logpower_notime_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void F77_NAME(logpower_time_wrapper)(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);

static const R_FortranMethodDef FortranEntries[] = {
    {"computeparameter",                   (DL_FUNC) &F77_NAME(computeparameter),                    9},
    {"computeparametergeelog",             (DL_FUNC) &F77_NAME(computeparametergeelog),              9},
    {"computeparametergeelogit",           (DL_FUNC) &F77_NAME(computeparametergeelogit),            9},
    {"computeparameterlog",                (DL_FUNC) &F77_NAME(computeparameterlog),                 9},
    {"computeparameterlogit",              (DL_FUNC) &F77_NAME(computeparameterlogit),              13},
    {"continuouspower_gee_notime_wrapper", (DL_FUNC) &F77_NAME(continuouspower_gee_notime_wrapper), 14},
    {"continuouspower_gee_time_wrapper",   (DL_FUNC) &F77_NAME(continuouspower_gee_time_wrapper),   14},
    {"herzo",                              (DL_FUNC) &F77_NAME(herzo),                               4},
    {"legendre_handle",                    (DL_FUNC) &F77_NAME(legendre_handle),                     6},
    {"linearpower_gee_notime_wrapper",     (DL_FUNC) &F77_NAME(linearpower_gee_notime_wrapper),     13},
    {"linearpower_gee_wrapper",            (DL_FUNC) &F77_NAME(linearpower_gee_wrapper),            13},
    {"linearpower_notime_wrapper",         (DL_FUNC) &F77_NAME(linearpower_notime_wrapper),         15},
    {"linearpower_time_wrapper",           (DL_FUNC) &F77_NAME(linearpower_time_wrapper),           18},
    {"logitpower_gee_notime_wrapper",      (DL_FUNC) &F77_NAME(logitpower_gee_notime_wrapper),      13},
    {"logitpower_gee_wrapper",             (DL_FUNC) &F77_NAME(logitpower_gee_wrapper),             13},
    {"logitpower_notime_wrapper",          (DL_FUNC) &F77_NAME(logitpower_notime_wrapper),          13},
    {"logitpower_time_wrapper",            (DL_FUNC) &F77_NAME(logitpower_time_wrapper),            14},
    {"logpower_gee_notime_wrapper",        (DL_FUNC) &F77_NAME(logpower_gee_notime_wrapper),        13},
    {"logpower_gee_wrapper",               (DL_FUNC) &F77_NAME(logpower_gee_wrapper),               13},
    {"logpower_notime_wrapper",            (DL_FUNC) &F77_NAME(logpower_notime_wrapper),            15},
    {"logpower_time_wrapper",              (DL_FUNC) &F77_NAME(logpower_time_wrapper),              18},
    {NULL, NULL, 0}
};

void R_init_swdpwr(DllInfo *dll)
{
    R_registerRoutines(dll, NULL, NULL, FortranEntries, NULL);
    R_useDynamicSymbols(dll, FALSE);
}
